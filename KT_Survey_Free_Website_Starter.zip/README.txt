KT SURVEY WEBSITE - QUICK START

Files:
- index.html: website content
- styles.css: design and responsive layout

PREVIEW:
Open index.html in a web browser.

BEFORE PUBLISHING:
1. Replace "Add your business email" with your official email address.
2. Replace "Add your business phone number" with your business phone/WhatsApp number.
3. Check every service and classification listed and remove anything you do not offer.
4. Add your approved logo and real project/sample-report images if available.
5. Confirm any experience, location, and business claims before adding them.

FREE PUBLISHING OPTION: GITHUB PAGES
1. Create/sign in to a GitHub account at https://github.com/
2. Create a new public repository, for example: kt-survey-website
3. Upload index.html and styles.css to the repository's main/root folder.
4. Open repository Settings -> Pages.
5. Under Build and deployment, choose "Deploy from a branch".
6. Select branch "main" and folder "/ (root)", then Save.
7. GitHub will provide your public website address after deployment.

A free GitHub Pages address will look like:
https://YOUR-USERNAME.github.io/kt-survey-website/

A custom domain usually costs money, so use the free GitHub Pages address to start.
